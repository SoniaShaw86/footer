declare interface IHeaderAndFooterAppExtensionApplicationCustomizerStrings {
  Title: string;
}

declare module 'HeaderAndFooterAppExtensionApplicationCustomizerStrings' {
  const strings: IHeaderAndFooterAppExtensionApplicationCustomizerStrings;
  export = strings;
}
