define([], function() {
  return {
    "Title": "HeaderAndFooterAppExtensionApplicationCustomizer"
  }
});