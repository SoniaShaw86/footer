import { override } from '@microsoft/decorators';
import { Log } from '@microsoft/sp-core-library';
import { 
  BaseApplicationCustomizer, 
  PlaceholderContent, 
  PlaceholderName 
  } from '@microsoft/sp-application-base';
import { Dialog } from '@microsoft/sp-dialog';

import * as strings from 'HeaderAndFooterAppExtensionApplicationCustomizerStrings';
import styles from './HeaderAndFooterAppExtensionApplicationCustomizer.module.scss';
const LOG_SOURCE: string = 'HeaderAndFooterAppExtensionApplicationCustomizer';

/**
 * If your command set uses the ClientSideComponentProperties JSON input,
 * it will be deserialized into the BaseExtension.properties object.
 * You can define an interface to describe it.
 */
export interface IHeaderAndFooterAppExtensionApplicationCustomizerProperties

 {

  // This is an example; replace with your own property

  //testMessage: string;

  Top: string;  

  Bottom: string;

}

/** A Custom Action which can be run during execution of a Client Side Application */
export default class HeaderAndFooterAppExtensionApplicationCustomizer
  extends BaseApplicationCustomizer<IHeaderAndFooterAppExtensionApplicationCustomizerProperties> {
    private _topPlaceholderHeader: PlaceholderContent | undefined;

    private _bottomPlaceholderFooter: PlaceholderContent | undefined;
    
      @override
    
      public onInit(): Promise<void> 
    
      {
    
        Log.info(LOG_SOURCE, `Initialized ${strings.Title}`);
    
        this.context.placeholderProvider.changedEvent.add(this, this._renderPlaceHoldersHeaderandFooter);
    
        //Added the below line code to handle the possible changes on the existence of placeholders.  
    
        this.context.placeholderProvider.changedEvent.add(this, this._renderPlaceHoldersHeaderandFooter);  
         
    
        //The below code is used to call render method for generating the HTML elements.  
    
        this._renderPlaceHoldersHeaderandFooter(); 
    
    
        return Promise.resolve();
    
      }

      private _renderPlaceHoldersHeaderandFooter(): void

   {  

    console.log('HeaderAndFooterAppExtensionApplicationCustomizer._renderPlaceHoldersHeaderandFooter()');  

    console.log('Available placeholders are as below: ',  

    this.context.placeholderProvider.placeholderNames.map(name => PlaceholderName[name]).join(', '));  

      

    //Handling the top placeholder - header section

    if (!this._topPlaceholderHeader)

     {  

      this._topPlaceholderHeader =  

        this.context.placeholderProvider.tryCreateContent(  

          PlaceholderName.Top,  

          { 

            onDispose: this._onDispose

          });  

      

      //The extension should not assume that the expected placeholder is available.  

      if (!this._topPlaceholderHeader)

       {  

        console.error('The expected placeholder (top heder) was not found.');  

        return;  

      }  

      

      if (this.properties) {  

        let topString: string = this.properties.Top;  

        if (!topString) {  

          topString = '(The top header property was not defined.)';  

        }  

      

        if (this._topPlaceholderHeader.domElement)

         {  

          this._topPlaceholderHeader.domElement.innerHTML = `  

            <div class="${styles.appCustomHeaderFooter}">  

              <div class="ms-bgColor-themeDark ms-fontColor-white ${styles.top}">  

                <i class="ms-Icon ms-Icon--Info" aria-hidden="true"></i> ${escape(topString)}  

              </div>  

            </div>`;  

        }  

      }  

    }  

      

    //Handling the bottom placeholder - Footer section

    if (!this._bottomPlaceholderFooter)

     {  

      this._bottomPlaceholderFooter =  

        this.context.placeholderProvider.tryCreateContent(  

          PlaceholderName.Bottom,  

          { onDispose: this._onDispose });  

      

      // The extension should not assume that the expected placeholder is available.  

      if (!this._bottomPlaceholderFooter) {  

        console.error('The expected placeholder (Bottom Footer) was not found.');  

        return;  

      }  

      

      if (this.properties) {  

        let bottomString: string = this.properties.Bottom;  

        if (!bottomString) {  

          bottomString = '(The bottom footer property was not defined.)';  

        }  

      

        if (this._bottomPlaceholderFooter.domElement)

        {  

          this._bottomPlaceholderFooter.domElement.innerHTML = `  

            <div class="${styles.appCustomHeaderFooter}">  

              <div class="ms-bgColor-themeDark ms-fontColor-white ${styles.bottom}">  

                <i class="ms-Icon ms-Icon--Info" aria-hidden="true"></i> ${escape(bottomString)}  

              </div>  

            </div>`;  

        }  

      }  

    }  

 }
 private _onDispose(): void 

 {

   console.log('[HeaderAndFooterAppExtensionApplicationCustomizer._onDispose] Disposed from the top header and bottom footer placeholders.');

 }
}
