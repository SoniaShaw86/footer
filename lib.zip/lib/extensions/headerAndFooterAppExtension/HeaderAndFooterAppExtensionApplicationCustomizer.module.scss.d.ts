declare const styles: {
    appCustomHeaderFooter: string;
    top: string;
    bottom: string;
};
export default styles;
//# sourceMappingURL=HeaderAndFooterAppExtensionApplicationCustomizer.module.scss.d.ts.map